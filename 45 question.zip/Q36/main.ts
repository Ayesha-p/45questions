function make_shirt(size: string, message: string){
    console.log(`The shirt size is ${size} and it has the message: "${message}" printed on it.`);
}

make_shirt("Medium", "Dream Big, Work Hard");
make_shirt("Large", "Code is Poetry");
make_shirt("Small", "Adventure Awaits");