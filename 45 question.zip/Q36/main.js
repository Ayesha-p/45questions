function make_shirt(size, message) {
    console.log("The shirt size is ".concat(size, " and it has the message: \"").concat(message, "\" printed on it."));
}
make_shirt("Medium", "Dream Big, Work Hard");
make_shirt("Large", "Code is Poetry");
make_shirt("Small", "Adventure Awaits");
