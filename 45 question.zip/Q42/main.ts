let magicians: string[] = ['Harry Houdini', 'Dai Vernon	', 'RICKY JAY', 'Dynamo'];

function showMagicians(magicians: string[]): void {
    for (let magician = 0 ;magician<magicians.length;magician++) {
        console.log(magicians[magician]);
    }
}

function makeGreat(magicians: string[]): void {
    for (let i = 0; i < magicians.length; i++) {
        magicians[i] = "the Great " + magicians[i];
    }
}
makeGreat(magicians);
showMagicians(magicians);
