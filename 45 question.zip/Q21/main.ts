type Item = {
    name: string;
    quantity: number;
    price: number;
};

const inventory: { [key: string]: Item } = {
    'item1': {
        name: 'Apple',
        quantity: 10,
        price: 0.5
    },
    'item2': {
        name: 'Banana',
        quantity: 5,
        price: 0.3
    },
    'item3': {
        name: 'Orange',
        quantity: 8,
        price: 0.4
    }
};

console.log(inventory['item1']); 
console.log(inventory['item2'].price); 
