console.log("Addition:", 5+3)
console.log("Subtraction:", 20-12)
console.log("Multiplication :", 4*2)
console.log("Division :", 16/2)