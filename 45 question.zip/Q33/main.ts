const numbers: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9];

for (let i =0;i< numbers.length ; i++) {
    let suffix: string;
    if (numbers[i] % 10 === 1 && numbers[i] % 100 !== 11) {
        suffix = 'st';
    } else if (numbers[i] % 10 === 2 && numbers[i] % 100 !== 12) {
        suffix = 'nd';
    } else if (numbers[i] % 10 === 3 && numbers[i] % 100 !== 13) {
        suffix = 'rd';
    } else {
        suffix = 'th';
    }

    console.log(`${numbers[i]}${suffix}`);
}

