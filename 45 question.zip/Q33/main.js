var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
for (var i = 0; i < numbers.length; i++) {
    var suffix = void 0;
    if (numbers[i] % 10 === 1 && numbers[i] % 100 !== 11) {
        suffix = 'st';
    }
    else if (numbers[i] % 10 === 2 && numbers[i] % 100 !== 12) {
        suffix = 'nd';
    }
    else if (numbers[i] % 10 === 3 && numbers[i] % 100 !== 13) {
        suffix = 'rd';
    }
    else {
        suffix = 'th';
    }
    console.log("".concat(numbers[i]).concat(suffix));
}
