

let alien_color: string = 'green'; 

if (alien_color === 'green') {
    console.log('Congratulations! You just earned 5 points for shooting the alien.');
} else {
    console.log('Congratulations! You just earned 10 points for shooting the alien.');
}


alien_color = 'red'; 

if (alien_color === 'green') {
    console.log('Congratulations! You just earned 5 points for shooting the alien.');
} else {
    console.log('Congratulations! You just earned 10 points for shooting the alien.');
}
