var alien_color = 'green';
if (alien_color === 'green') {
    console.log('Congratulations! You just earned 5 points.');
}
else {
    console.log('No points earned.');
}
alien_color = 'yellow';
if (alien_color === 'green') {
    console.log('Congratulations! You just earned 5 points.');
}
else {
    console.log('No points earned.');
}
