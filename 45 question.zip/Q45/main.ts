

type myCar = {
    manufacturer: string;
    modelName: string;
    [key: string]: any;
};

function create_car(manufacturer: string, modelName: string, additionalProps: { [key: string]: any }): myCar {
    return {
        manufacturer,
        modelName,
        ...additionalProps
    };
}


console.log(create_car('Honda', 'Civic', { color: 'black', year: 2022 }));
