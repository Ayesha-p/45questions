var guest = ["Saba", "Jiya", "Hira"];
for (var i = 0; i < guest.length; i++) {
    console.log(guest[i] + "I would be honored to have you as my guest for dinner.");
}
