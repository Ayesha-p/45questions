let guest : string[] = ["Saba", "Jiya" , "Hira"]

for (let i = 0 ; i <guest.length ; i++){

    console.log( guest[i] + "I would be honored to have you as my guest for dinner." )
}