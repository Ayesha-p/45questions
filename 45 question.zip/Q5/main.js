var famous_Person = "Jinnah";
var message = '"Think a hundred times before you take a decision, but once that decision is taken, stand by it as one man."';
console.log("".concat(famous_Person, " ones Said, ").concat(message));
