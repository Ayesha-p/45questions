let famous_Person = "Jinnah"
let message = '"Think a hundred times before you take a decision, but once that decision is taken, stand by it as one man."'
console.log(`${famous_Person} ones Said, ${message}`);








