type Album = {
    artist: string;
    title: string;
    tracks?: number;  
};
function makeAlbum(artistName: string, albumTitle: string, numberOfTracks?: number): Album {
    const album: Album = {
        artist: artistName,
        title: albumTitle
    };
    if (numberOfTracks !== undefined) {
        album.tracks = numberOfTracks;
    }
    return album;
}
const album1 = makeAlbum('Adele', '25');
const album2 = makeAlbum('Taylor Swift', 'Folklore');
const album3 = makeAlbum('Kanye West', 'Donda', 27);

console.log(album1);
console.log(album2);
console.log(album3);
