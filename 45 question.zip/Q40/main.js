function makeAlbum(artistName, albumTitle, numberOfTracks) {
    var album = {
        artist: artistName,
        title: albumTitle
    };
    if (numberOfTracks !== undefined) {
        album.tracks = numberOfTracks;
    }
    return album;
}
var album1 = makeAlbum('Adele', '25');
var album2 = makeAlbum('Taylor Swift', 'Folklore');
var album3 = makeAlbum('Kanye West', 'Donda', 27);
console.log(album1);
console.log(album2);
console.log(album3);
