// Name: Ayesha
// Date: June 25, 2024
// This program demonstrates the usage of comments in TypeScript.
//console.log(`"Jinnah once said, 'Think a hundred times before you take a decision, but once that decision is taken, stand by it as one man.'"`);
var description = "The following line of code prints a quote by Jinnah to the console.";
console.log(description);
// let favoriteNumber = 7
// console.log(`My favorite number is ${favoriteNumber}.`);
var description2 = "The following line of code prints a Favorite number to the console.";
console.log(description2);
