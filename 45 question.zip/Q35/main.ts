let animals: string[] = ["Parrot", "Goldfish", "Hamster"];

for (let i=0;i<animals.length;i++) {
    console.log(`A ${animals[i]} would make a great pet.`);
}

console.log("Any of these animals would make a great pet!");
