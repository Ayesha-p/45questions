var animals = ["Parrot", "Goldfish", "Hamster"];
for (var i = 0; i < animals.length; i++) {
    console.log("A ".concat(animals[i], " would make a great pet."));
}
console.log("Any of these animals would make a great pet!");
