var alienColor = 'green';
if (alienColor === 'green') {
    console.log('Congratulations! You earned 5 points.');
}
else if (alienColor === 'yellow') {
    console.log('Congratulations! You earned 10 points.');
}
else if (alienColor === 'red') {
    console.log('Congratulations! You earned 15 points.');
}
else {
    console.log('No points for this color.');
}
alienColor = 'yellow';
if (alienColor === 'green') {
    console.log('Congratulations! You earned 5 points.');
}
else if (alienColor === 'yellow') {
    console.log('Congratulations! You earned 10 points.');
}
else if (alienColor === 'red') {
    console.log('Congratulations! You earned 15 points.');
}
else {
    console.log('No points for this color.');
}
alienColor = 'red';
if (alienColor === 'green') {
    console.log('Congratulations! You earned 5 points.');
}
else if (alienColor === 'yellow') {
    console.log('Congratulations! You earned 10 points.');
}
else if (alienColor === 'red') {
    console.log('Congratulations! You earned 15 points.');
}
else {
    console.log('No points for this color.');
}
