var personName = "\t Ayesha \n";
console.log("Name with white Space:", personName);
console.log("Stripped name:", personName.trim());
