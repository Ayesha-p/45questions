function makeSandwich(...items: string[]): void {
    console.log("Your sandwich includes the following items:");
    for( let i=0 ;i<items.length;i++){
         console.log(`- ${items[i]}`);
    }
    console.log("Enjoy your sandwich!\n");
}

makeSandwich("Chicken Tikka", "Green Chili", "Onion", "Cheese");
makeSandwich("Beef Kebabs", "Tomato", "Capsicum");
makeSandwich("Paneer", "Mint Chutney");