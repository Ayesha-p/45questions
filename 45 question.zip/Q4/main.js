console.log("\" Jinnah  once said , Think a hundred times before you take a decision, but once that decision is taken, stand by it as one man.\"");
