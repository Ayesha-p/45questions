const current_users: string[] = ['Ayesha', 'Kinza', 'Hira', 'Jiya', 'Hareem'];
const new_users: string[] = ['ayesha', 'kinza', 'hira', 'Tabi', 'Madiha'];
function check_usernames(currentUsers: string[], newUsers: string[]): void {
    for (const newUser of newUsers) {
        const newUserLower = newUser.toLowerCase();
        if (currentUsers.some(user => user.toLowerCase() === newUserLower)) {
            console.log(`${newUser} has already been used. Please enter a new username.`);
        } else {
            console.log(`${newUser} is available.`);
        }
    }
}

check_usernames(current_users, new_users);
