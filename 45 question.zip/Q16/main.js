var guests = ["Saba", "Jiya", "Hira"];
var unavailableGuest = guests[1];
console.log(unavailableGuest + " can't make it to the dinner.");
guests[1] = "Ayesha";
for (var i = 0; i < guests.length; i++) {
    console.log('Dear ' + guests[i] + ', I would be honored to have you as my guest for dinner.');
}
console.log("\n\nwe found a bigger dinner table.\n\n");
guests.unshift("Asma");
guests.push("Aiman");
guests.splice(2, 0, "Hina");
for (var i = 0; i < guests.length; i++) {
    console.log('Dear ' + guests[i] + ', I would be honored to have you as my guest for dinner.');
}
