var favorite_fruits = ["Apple", "Mango", "Orange"];
function isFavoriteFruit(fruit) {
    for (var i = 0; i < favorite_fruits.length; i++) {
        if (favorite_fruits[i] === fruit) {
            return true;
        }
    }
    return false;
}
if (isFavoriteFruit('Apple')) {
    console.log("I really like Apple!");
}
if (isFavoriteFruit('Mango')) {
    console.log("I really like Mango!");
}
if (isFavoriteFruit('Orange')) {
    console.log("I really like Orange!");
}
if (isFavoriteFruit('Banana')) {
    console.log("I really like Banana!");
}
if (isFavoriteFruit('Pineapple')) {
    console.log("I really like Pineapple!");
}
