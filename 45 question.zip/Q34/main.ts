let favorite_pizzas: string[] = ["Pepperoni", "Fajita", "BBQ Chicken"];

for (let i=0 ;i< favorite_pizzas.length;i++) {
    console.log(`I like ${favorite_pizzas[i]} pizza.`);
}

console.log("I really love pizza!");
