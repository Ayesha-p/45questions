var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var places = ['Tokyo', 'Paris', 'New York', 'Sydney', 'Cape Town'];
console.log('Original array:', places);
var alphabeticalOrder = places.sort();
console.log('Alphabetical order:', alphabeticalOrder);
console.log('Still original order:', places);
var reverseAlphabeticalOrder = __spreadArray([], places, true).sort().reverse();
console.log('Reverse alphabetical order:', reverseAlphabeticalOrder);
console.log('Still original order:', places);
places.reverse();
console.log('Reversed order:', places);
places.reverse();
console.log('Back to original order:', places);
places.sort();
console.log('Alphabetical order after sort:', places);
places.sort().reverse();
console.log('Reverse alphabetical order after sort:', places);
