let places: string[] = ['Lahore', 'Karachi', 'Islamabad', 'Peshawar', 'Quetta'];

console.log('Original array:', places);

let alphabeticalOrder = [...places].sort();
console.log('Alphabetical order:', alphabeticalOrder);

console.log('Still original order:', places);

let reverseAlphabeticalOrder = [...places].sort().reverse();
console.log('Reverse alphabetical order:', reverseAlphabeticalOrder);

console.log('Still original order:', places);

places.reverse();
console.log('Reversed order:', places);

places.reverse();
console.log('Back to original order:', places);

places.sort();
console.log('Alphabetical order after sort:', places);

places.sort().reverse();
console.log('Reverse alphabetical order after sort:', places);
