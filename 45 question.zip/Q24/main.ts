let str1 = "hello";
let str2 = "world";
let str3 = "TypeScript";
let str4 = "typescript";
let num1 = 10;
let num2 = 5;
let num3 = 15;

let fruits = ["apple", "banana", "cherry"];
let colors = ["red", "green", "blue"];

// 1. Equality and Inequality with Strings
console.log("String Equality Tests:");
console.log(`str1 === "hello": ${str1 === "hello"}`); 
console.log(`str1 === str2: ${str1 === str2}`);    
console.log(`str1 !== "world": ${str1 !== "world"}`); 
console.log(`str1 !== "hello": ${str1 !== "hello"}`); 


console.log("\nString Lowercase Tests:");

console.log(`str3.toLowerCase() === str4: ${str3.toLowerCase() === str4}`);  
console.log(`str3.toLowerCase() !== str4: ${str3.toLowerCase() !== str4}`);  

// 2. Numerical Tests
console.log("\nNumerical Tests:");
console.log(`num1 === 10: ${num1 === 10}`);           
console.log(`num1 !== 5: ${num1 !== 5}`);            
console.log(`num1 !== 10: ${num1 !== 10}`);           
console.log(`num1 > num2: ${num1 > num2}`);          
console.log(`num1 < num2: ${num1 < num2}`);          
console.log(`num1 >= 10: ${num1 >= 10}`);          
console.log(`num2 <= 5: ${num2 <= 5}`);           
console.log(`num1 >= 11: ${num1 >= 11}`);          
console.log(`num2 <= 4: ${num2 <= 4}`);            


// 3. Using "and" and "or" Operators
console.log("\nLogical Operators:");
console.log(`a < b && b < c: ${num2 < num1 && num1 < num3}`);    
console.log(`a > b && b < c: ${num2 > num1 && num1 < num3}`);   
console.log(`a < b || b > c: ${num2 < num1 || num1 > num3}`);    
console.log(`a > b || b < c: ${num2 > num1 || num1 < num3}`);    
console.log(`a > b || b > c: ${num2 > num1 || num1 > num3}`);   

// // 4. Test Whether an Item is in an Array


console.log("\nArray Membership Tests:");
console.log(`"banana" is in fruits: ${fruits.indexOf("banana") !== -1}`);  
console.log(`"grape" is in fruits: ${fruits.indexOf("grape") !== -1}`);   

// 5. Test Whether an Item is Not in an Array

console.log("\nArray Non-Membership Tests:");
console.log(`"yellow" is not in colors: ${colors.indexOf("yellow") === -1}`); 
console.log(`"green" is not in colors: ${colors.indexOf("green") === -1}`);  
