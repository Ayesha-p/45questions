let car = 'subaru';
console.log("Test 1: Is car == 'subaru'? I predict True.");
console.log(car == 'subaru'); 

console.log("\nTest 2: Is car != 'toyota'? I predict True.");
console.log(car != 'toyota'); 

console.log("\nTest 3: Is car == 'Subaru'? I predict False.");	
console.log(car == 'Subaru');

console.log("\nTest 4: Is car === 'subaru'? I predict True.");
console.log(car === 'subaru'); 

console.log("\nTest 5: Is car !== 'subaru'? I predict False.");
console.log(car !== 'subaru');

console.log("\nTest 6: Is car == ' subaru '? I predict False.");
console.log(car == ' subaru '); 

console.log("\n Test 7: car.length == 6? I predict True.");
console.log(car.length==6); 

console.log("\n Test 8: Is car.length > 10? I predict False.");
console.log(car.length>10);

console.log("\nTest 9: Is car == 'toyota'? I predict False.");
console.log(car == 'toyota'); 

console.log("\nTest 10: Is the length of car > 5? I predict True.");
console.log(car.length > 5); 
