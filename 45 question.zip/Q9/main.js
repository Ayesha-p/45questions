var favorite_number = 7;
console.log("My favorite number is ".concat(favorite_number, "."));
