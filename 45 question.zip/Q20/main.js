var countries = [
    "Pakistan",
    "United Kingdom",
    "Germany",
    "France",
    "Japan",
    "Australia"
];
for (var i = 0; i < countries.length; i++) {
    console.log(countries[i]);
}
