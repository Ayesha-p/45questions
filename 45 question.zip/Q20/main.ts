let countries: string[] = [ 
    "Pakistan",
    "United Kingdom",
    "Germany",
    "France",
    "Japan",
    "Australia"
];



for (let i = 0; i < countries.length; i++) {
    console.log(countries[i]);
}

