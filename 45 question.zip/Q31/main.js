var users = ['Ayesha', 'Bilal', 'Ani'];
if (users.length === 0) {
    console.log("We need to find some users!");
}
else {
    users = [];
    console.log("All user have been removed!" + users.length);
}
