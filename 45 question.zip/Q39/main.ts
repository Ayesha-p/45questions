function city_country(city:string,country:string){
 let cityCountry=city+","+country;
return cityCountry;
}
console.log(city_country("karachi","Pakistan"));
console.log(city_country("Lahore","Pakistan"));
console.log(city_country("Islamabad","Pakistan"));