let transportation: string[] = ["Motorcycle", "Car" , "Bus" , "Truck" , "Auto"];

for (let  i = 0 ; i < transportation.length ; i++ ){
    console.log(`I would like to own a ${transportation[i]}`)
}


