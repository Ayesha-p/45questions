var transportation = ["Motorcycle", "Car", "Bus", "Truck", "Auto"];
for (var i = 0; i < transportation.length; i++) {
    console.log("I would like to own a ".concat(transportation[i]));
}
