var guests = ["Saba", "Jiya", "Hira"];
var unavailableGuest = guests[1];
console.log(unavailableGuest + " can't make it to the dinner.");
guests[1] = "Ayesha";
for (var i = 0; i < guests.length; i++) {
    console.log('Dear ' + guests[i] + ', I would be honored to have you as my guest for dinner.');
}
console.log("\n\nwe found a bigger dinner table.\n\n");
guests.unshift("Asma");
guests.push("Aiman");
guests.splice(2, 0, "Hina");
for (var i = 0; i < guests.length; i++) {
    console.log('Dear ' + guests[i] + ', I would be honored to have you as my guest for dinner.');
}
console.log("\n\n you can invite only two people for dinner.\n\n");
for (var i = 0; i < 4; i++) {
    var removedGuest = guests.pop();
    console.log("Sorry, ".concat(removedGuest, ", I can\u2019t invite you to dinner."));
}
for (var i = 0; i < guests.length; i++) {
    console.log('Dear ' + guests[i] + ', you’re still invited to dinner.');
}
guests.splice(0, guests.length);
console.log('The guest list is now empty:', guests);
