let magicians: string[] = ["Harry Houdini", "David Blaine", "Penn Jillette", "Teller"];

function showMagicians(magicians: string[]): void {
    for (let magician of magicians) {
        console.log(magician);
    }
}

function makeGreat(magicians: string[]): string[] {
    let greatMagicians: string[] = [];
    for (let magician of magicians) {
        greatMagicians.push(magician + " the Great");
    }
    return greatMagicians;
}

let greatMagicians = makeGreat([...magicians]);

console.log("Original magicians:");
showMagicians(magicians);

// Show the new array of magicians with "the Great" added
showMagicians(greatMagicians);
