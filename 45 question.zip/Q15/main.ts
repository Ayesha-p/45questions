let guests: string[] = ["Saba", "Jiya", "Hira"];

let unavailableGuest = guests[1]; 

console.log(unavailableGuest + " can't make it to the dinner.");

guests[1] = "Ayesha"; 

for (let i = 0; i < guests.length; i++) {
    console.log('Dear ' + guests[i] + ', I would be honored to have you as my guest for dinner.');
}
