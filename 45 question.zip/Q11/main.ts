
let names: string[] = ["Ramsha", "Sana", "Asma", "Arzo"];

for (let i = 0; i < names.length; i++) {
    console.log(names[i]);
}
