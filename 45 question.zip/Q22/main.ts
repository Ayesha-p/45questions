let language :string[] = ["Urdu" , "Sindhi" , "Punjabi" , "Puchto" , "Blochi" ];
console.log(language[3])
console.log(language[7])