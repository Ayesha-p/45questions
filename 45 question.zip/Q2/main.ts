let firstName = "Ayesha";
console.log(`Hellow ${firstName}, would you like to learn some Python today?`);