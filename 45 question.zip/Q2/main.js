var firstName = "Ayesha";
console.log("Hellow ".concat(firstName, ", would you like to learn some Python today?"));
